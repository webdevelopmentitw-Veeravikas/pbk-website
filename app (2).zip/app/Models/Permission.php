<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Model;

class Permission extends Model
{
    protected string $table = 'permissions';

    protected array $fillable = [
        'name',
        'slug',
        'group_name',
    ];
}
